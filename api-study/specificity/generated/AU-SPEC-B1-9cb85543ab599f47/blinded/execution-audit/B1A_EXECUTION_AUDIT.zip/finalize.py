from pathlib import Path
import json,hashlib,datetime,zipfile
r=Path(__file__).resolve().parent; d=r/'deliverables'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_bytes())
def pairs(items):
 result={}
 for k,v in items:
  if k in result: raise ValueError('Duplicate JSON key: '+k)
  result[k]=v
 return result
plan=load(r/'launch_plan.json'); results=[]; attempts=[]
for entry in plan:
 c=entry['coder_id']; original=r/'original_responses'/f'{c}_ORIGINAL_RESPONSE.txt'
 b=original.read_bytes(); obj=json.loads(b,object_pairs_hook=pairs)
 checks={
  'single_json_object':isinstance(obj,dict),
  'top_level_fields':set(obj)=={'schema_version','packet_id','coder_id','coder_metadata','codes'},
  'schema_version':obj.get('schema_version')=='au-specificity-codes-v1',
  'packet_id':obj.get('packet_id')=='AU-SPEC-B1-9cb85543ab599f47',
  'coder_id':obj.get('coder_id')==c,
  'metadata_fields':isinstance(obj.get('coder_metadata'),dict) and set(obj['coder_metadata'])=={'service','model','settings','started_at_utc','completed_at_utc'},
  'metadata_values':isinstance(obj.get('coder_metadata'),dict) and all(v is None or isinstance(v,str) for v in obj['coder_metadata'].values()),
  'codes_array':isinstance(obj.get('codes'),list)
 }
 rows=obj.get('codes',[])
 checks['code_row_shape']=all(isinstance(x,dict) and set(x)=={'card_id','code'} and isinstance(x['card_id'],str) for x in rows)
 ids=[x.get('card_id') for x in rows]
 checks['169_rows']=len(rows)==169
 checks['169_unique_card_ids']=len(set(ids))==169
 checks['exact_card_ids']=set(ids)==set(entry['input_card_ids'])
 checks['designated_order']=ids==entry['input_card_ids']
 checks['string_codes_1_0_U']=all(isinstance(x.get('code'),str) and x['code'] in {'1','0','U'} for x in rows)
 passed=all(checks.values()); results.append({'coder_id':c,'passed':passed,'checks':checks})
 if passed: (d/f'{c}_CODES.json').write_bytes(b)
 attempts.append({'coder_id':c,'child_identifier':'/root/'+entry['spawn_arguments']['task_name'],'spawn_tool':'collaboration.spawn_agent','spawn_arguments':entry['spawn_arguments'],'launch_at_utc':None,'launch_observation_window_utc':{'start':(r/'launch_window_start.txt').read_text(),'end':(r/'launch_window_end.txt').read_text()},'completed_at_utc':None,'completion_observed_at_utc':load(r/'completion_observations.json')[c],'service':'ChatGPT Work','actual_model':None,'actual_reasoning_setting':None,'model_override':None,'reasoning_override':None,'original_response_file':original.name,'original_response_sha256':sha(original),'code_file':f'{c}_CODES.json' if passed else None,'code_file_sha256':sha(d/f'{c}_CODES.json') if passed else None,'corrections':[],'replacements':[]})
report={'schema_version':'b1a-mechanical-validation-v1','validated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'JSON/schema shape, packet and coder IDs, 169 exact unique card IDs, designated order, string codes 1/0/U only','semantic_validation_performed':False,'vote_summary_computed':False,'agreement_computed':False,'adjudication_performed':False,'all_passed':all(x['passed'] for x in results),'results':results}
(d/'MECHANICAL_VALIDATION_REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
record={'schema_version':'b1a-coordinator-execution-v1','packet_id':'AU-SPEC-B1-9cb85543ab599f47','service':'ChatGPT Work','parent_configuration':{'selected_model_user_reported':'Astra','selected_intelligence_user_reported':'Light','actual_backend_model_identifier':None,'actual_backend_reasoning_setting':None,'configuration_changed_by_coordinator':False},'b1a_adoption':{'confirmed_by':'user','commit':'89eee5615a56b071595a4aba748aa5d1e1b88a99','adopted_before_launch_user_confirmed':True,'repository_or_signature_independently_checked':False},'context_configuration':{'source':'user confirmation before coder dispatch; not independently inspected','user_states_set_before_task':True,'memory':'off','library_access':'off','writing_style_reference':'off','reference_record_history':'off','personalization_prompt':'not configured','custom_instructions':'not configured','account_settings_changed_by_coordinator':False,'backend_state_independently_verified':False},'limitations':['fork_turns none explicitly omits parent conversation history; it does not certify absence of other platform-provided context.','All agents share the filesystem and available tools; spawn exposes no per-child file allowlist, tool disabling, or communication disabling control.','Each spawn message supplied only the prescribed coder instruction and paths to that coder\'s four exact-byte files. No ZIP, manifest, setup conversation, other coder materials, or other coder outputs were included in messages. Broader filesystem access was not technically revoked.','Persistent memory and custom-instruction injection into history-free children, settings sampling time, and separate attachment exposure are not established by available controls.','User-selected Astra Light is recorded; no backend model or reasoning identity was independently exposed by spawn. Child metadata is self-report and is not used as isolation evidence.','Exact service-side launch and completion timestamps are not exposed; coordinator observation windows/timestamps are recorded separately.','Responses are preserved as exact exposed text encoded in UTF-8, without normalization; transport-level bytes before text delivery are not exposed.','Input manifest is not self-authenticating. All 12 payloads matched it; manifest and archive hashes are recorded independently.'],'concurrency_observation':load(r/'concurrency_observation.json'),'input_verification':load(r/'input_verification.json'),'attempts':attempts,'mechanical_validation_report':{'file':'MECHANICAL_VALIDATION_REPORT.json','sha256':sha(d/'MECHANICAL_VALIDATION_REPORT.json')},'coordinator_scope':'coordination, byte verification, and mechanical validation only; no coding or adjudication','external_sources_consulted':False,'prior_chats_or_personal_memories_retrieved':False,'unblinding_key_opened':False,'published_committed_or_pushed':False}
(d/'COORDINATOR_EXECUTION_RECORD.json').write_text(json.dumps(record,indent=2)+'\n')
with zipfile.ZipFile(d/'B1A_EXECUTION_AUDIT.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((r/'original_responses').glob('*')): z.write(p,'original_responses/'+p.name)
 for n in ['INPUT_MANIFEST.json','input_verification.json','launch_plan.json','completion_observations.json','concurrency_observation.json','launch_window_start.txt','launch_window_end.txt','finalize.py']: z.write(r/n,n)
 for n in ['COORDINATOR_EXECUTION_RECORD.json','MECHANICAL_VALIDATION_REPORT.json']: z.write(d/n,n)
print(json.dumps({'all_passed':report['all_passed'],'results':results,'deliverables':[p.name for p in d.iterdir()]},indent=2))
